/*-- 1. Borrar esquema si existe
DROP SCHEMA IF EXISTS blockdesign;*/
CREATE SCHEMA blockdesign;

-- 2. Crear usuario de base de datos
/*DROP USER IF EXISTS 'block_user'@'%';*/
CREATE USER 'block_user'@'%' IDENTIFIED BY 'Clave123.';
GRANT ALL PRIVILEGES ON blockdesign.* TO 'block_user'@'%';
FLUSH PRIVILEGES;

-- 3. Tabla de usuarios 
CREATE TABLE blockdesign.usuario (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(20) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nombre VARCHAR(30) NOT NULL,
  correo VARCHAR(50),
  rol VARCHAR(20) NOT NULL, -- aquí va: 'ADMIN', 'USER', etc.
  activo BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE blockdesign.oferta (
  id_oferta INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(100) NOT NULL,
  descripcion TEXT NOT NULL,
  precio int,
  activa BOOLEAN DEFAULT TRUE
);

CREATE TABLE blockdesign.proyecto (
  id_proyecto INT AUTO_INCREMENT PRIMARY KEY,
  titulo      VARCHAR(100) NOT NULL,
  descripcion VARCHAR(1000),
  fecha_fin   DATE,
  enlace      VARCHAR(200),
  id_usuario  int NOT NULL,
  CONSTRAINT fk_proyecto_usuario
  FOREIGN KEY (id_usuario)
  REFERENCES Usuario(id_usuario)
);

ALTER TABLE blockdesign.usuario ADD (cv_path VARCHAR(255));

USE blockdesign;
ALTER TABLE usuario
ADD COLUMN examen1_aprobado BOOLEAN DEFAULT FALSE,
ADD COLUMN examen2_aprobado BOOLEAN DEFAULT FALSE;

INSERT INTO blockdesign.proyecto (titulo, descripcion, fecha_fin, enlace, id_usuario)
VALUES (
  'Portafolio Web',
  'Sitio personal con Spring Boot y Thymeleaf',
  '2025-06-30',
  'https://github.com/tuusuario/portafolio',
  1
);

