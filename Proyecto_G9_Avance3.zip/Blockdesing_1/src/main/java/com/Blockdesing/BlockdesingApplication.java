package com.Blockdesing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockdesingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockdesingApplication.class, args);
	}

}
