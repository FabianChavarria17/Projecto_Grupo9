/*-- 1. Borrar esquema si existe
DROP SCHEMA IF EXISTS blockdesign;*/
CREATE SCHEMA blockdesign;

-- 2. Crear usuario de base de datos
/*DROP USER IF EXISTS 'block_user'@'%';*/
CREATE USER 'block_user'@'%' IDENTIFIED BY 'Clave123.';
GRANT ALL PRIVILEGES ON blockdesign.* TO 'block_user'@'%';
FLUSH PRIVILEGES;

-- 3. Tabla de usuarios 
CREATE TABLE blockdesign.usuario (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(20) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nombre VARCHAR(30) NOT NULL,
  correo VARCHAR(50),
  rol VARCHAR(20) NOT NULL, -- aquí va: 'ADMIN', 'USER', etc.
  activo BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
